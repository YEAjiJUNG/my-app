import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import countryPage from './countryPage';

function App() {
  return (
    
        <Router>
          <div className="App"> 
        <Switch>
          <Route path="/" component={(countryPage)} />
        </Switch>
        </div>
        </Router>
        
      );
    }

export default App;
