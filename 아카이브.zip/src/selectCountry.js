import React from 'react';
import {withRouter} from 'react-router-dom';
import './selectCountry.css';

function selectCountry(){
    return(
        <div className="box">
            <p>Country</p>
            <form>
            <label className="checkbox"><input type="checkbox" name="country" value="China">China</input></label>
            <label><input type="checkbox" name="country" value="China">China</input></label>
            </form>
            
        </div>
    )
}

export default withRouter(selectCountry);